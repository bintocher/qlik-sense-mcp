"""Qlik Sense MCP Server for Enterprise APIs."""

__version__ = "0.1.0"